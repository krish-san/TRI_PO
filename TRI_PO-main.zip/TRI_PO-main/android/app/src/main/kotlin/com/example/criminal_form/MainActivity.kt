package com.example.criminal_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
