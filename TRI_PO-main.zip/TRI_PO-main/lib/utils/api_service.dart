import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';

  static Future<http.StreamedResponse> submitPoliceEntry(
    Map<String, dynamic> data,
    File? photoFile,
  ) async {
    var uri = Uri.parse('\$baseUrl/police');
    var request = http.MultipartRequest('POST', uri);

    data.forEach((key, value) {
      if (value != null) {
        request.fields[key] = value.toString();
      }
    });

    if (photoFile != null) {
      final mimeType = lookupMimeType(photoFile.path) ?? 'image/jpeg';
      final mimeSplit = mimeType.split('/');
      request.files.add(
        await http.MultipartFile.fromPath(
          'photo',
          photoFile.path,
          contentType: MediaType(mimeSplit[0], mimeSplit[1]),
        ),
      );
    }

    return await request.send();
  }

  static Future<http.StreamedResponse> submitAccusedEntry(
    Map<String, dynamic> data,
    Map<String, File?> photoFiles,
  ) async {
    var uri = Uri.parse('\$baseUrl/accused');
    var request = http.MultipartRequest('POST', uri);

    data.forEach((key, value) {
      if (value != null) {
        request.fields[key] = value.toString();
      }
    });

    for (var entry in photoFiles.entries) {
      final file = entry.value;
      if (file != null) {
        final mimeType = lookupMimeType(file.path) ?? 'image/jpeg';
        final mimeSplit = mimeType.split('/');
        request.files.add(
          await http.MultipartFile.fromPath(
            entry.key,
            file.path,
            contentType: MediaType(mimeSplit[0], mimeSplit[1]),
          ),
        );
      }
    }

    return await request.send();
  }
}
